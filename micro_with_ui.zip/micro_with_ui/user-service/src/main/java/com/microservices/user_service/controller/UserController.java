package com.microservices.user_service.controller;

import com.microservices.user_service.entity.User;
import com.microservices.user_service.repository.UserRepository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:5174")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    // INSERT USER
    @PostMapping
    public User addUser(@RequestBody User user) {

        return userRepository.save(user);
    }

    // GET USER BY ID
    @GetMapping("/{id}")
    public String getUser(@PathVariable int id) {

        User user = userRepository.findById(id).orElse(null);

        if(user == null) {
            return "User Not Found";
        }

        return user.getName();
    }

    // GET ALL USERS
    @GetMapping
    public List<User> getAllUsers() {

        return userRepository.findAll();
    }
    // UPDATE
    @PutMapping("/{id}")
    public User updateUser(@PathVariable int id,
                           @RequestBody User updatedUser) {

        User user = userRepository.findById(id).orElse(null);

        if(user == null) {
            return null;
        }

        user.setName(updatedUser.getName());

        return userRepository.save(user);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable int id) {

        userRepository.deleteById(id);

        return "User Deleted Successfully";
    }
}