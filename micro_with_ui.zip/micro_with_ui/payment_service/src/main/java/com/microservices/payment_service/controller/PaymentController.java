package com.microservices.payment_service.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
@CrossOrigin(origins = "*")
public class PaymentController {

    @GetMapping("/{id}")
    public String makePayment(@PathVariable int id) {

        return "Payment Successful";
    }
}