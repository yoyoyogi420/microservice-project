package com.microservices.order_service.controller;

import com.microservices.order_service.dto.User;
import com.microservices.order_service.feign.UserClient;
import com.microservices.order_service.payment.PaymentClient;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
@CrossOrigin(origins = "http://localhost:5174")
public class OrderController {

    @Autowired
    private UserClient userClient;

    @Autowired
    private PaymentClient paymentClient;
    

    // OLD FLOW (GET)
    
    @GetMapping("/{id}")
    public String getOrder(@PathVariable int id) {

        String user = userClient.getUser(id);

       
        if(user.equals("User Not Found")) {

            return "Order Failed : User Not Found";
        }
        String payment = paymentClient.makePayment(id);
        return "Order Created For -> "
                + user
                + " | "
                + payment;
    }
    @GetMapping
    public List<User> getAllUsers() {
    	 List<User> user1 = userClient.getAllUsers();
        return user1;
    }

    // NEW FLOW (POST)
    @PostMapping
    public User createUser(@RequestBody User user) {

        return userClient.addUser(user);
    }
    // UPDATE
    @PutMapping("/{id}")
    public User updateUser(@PathVariable int id,
                           @RequestBody User user) {

        return userClient.updateUser(id, user);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String deleteUser(@PathVariable int id) {

        return userClient.deleteUser(id);
    }
}