package com.microservices.order_service.feign;

import com.microservices.order_service.dto.User;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

@FeignClient(name = "USER-SERVICE")
public interface UserClient {

    @PostMapping("/user")
    User addUser(@RequestBody User user);

    @GetMapping("/user/{id}")
    String getUser(@PathVariable int id);
    
    @GetMapping("/user")
    List<User> getAllUsers();
 // UPDATE
    @PutMapping("/user/{id}")
    User updateUser(@PathVariable int id,
                    @RequestBody User user);

    // DELETE
    @DeleteMapping("/user/{id}")
    String deleteUser(@PathVariable int id);
}